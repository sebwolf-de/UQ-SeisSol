import sys
from ..pymuqSamplingAlgorithms import *

sys.modules[__name__] = sys.modules['muq.pymuqSamplingAlgorithms']
