import sys
from ..pymuqUtilities import *

sys.modules[__name__] = sys.modules['muq.pymuqUtilities']
