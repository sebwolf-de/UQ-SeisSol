#ifndef MUQ_HAS_GTEST
#define MUQ_HAS_GTEST 
#endif

#ifndef MUQ_HAS_SUNDIALS
#define MUQ_HAS_SUNDIALS 1
#endif

#ifndef MUQ_HAS_MPI
#define MUQ_HAS_MPI 1
#endif

#ifndef MUQ_HAS_PARCER
#define MUQ_HAS_PARCER 1
#endif

#ifndef MUQ_HAS_OTF2
#define MUQ_HAS_OTF2 1
#endif

#ifndef MUQ_ANYCAST_COMPILES
#define MUQ_ANYCAST_COMPILES 0
#endif
